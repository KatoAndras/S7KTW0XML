package hu.domparse.S7KTW0;


import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DOMQueryS7KTW0 {

    public static void main(String[] args) {
    	
        try {
        	
        	// XMLS7KTW0.xml betoltes
            File inputFile = new File("XMLS7KTW0.xml");
            
            // Letrehozom a dokumentum epitot es betoltom
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);

            doc.getDocumentElement().normalize();

            
            
            // 1. Kiiratom a dolgozok nevet
            
            System.out.println("1. A dolgozok nevei: ");
            NodeList dolgozok = doc.getElementsByTagName("Dolgozo");
            
            for (int i = 0; i < dolgozok.getLength(); i++) {
            	
                Node node = dolgozok.item(i);
                
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                	
                    Element nevek = (Element) node;
                    System.out.println(nevek.getElementsByTagName("nev").item(0).getTextContent());
                }
            }
            
            

            // 2. Kiiratom a szolgaltatasok nevet es arat
            
            System.out.println("\n2. A szolgaltatsok neve es az araik: ");
            NodeList szolgaltatasok = doc.getElementsByTagName("Szolgaltatas");
            
            for (int i = 0; i < szolgaltatasok.getLength(); i++) {
            	
                Node node = szolgaltatasok.item(i);
                
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                	
                    Element NevAR = (Element) node;
                    String nev = NevAR.getElementsByTagName("nev").item(0).getTextContent();
                    String ar = NevAR.getElementsByTagName("ar").item(0).getTextContent();
                    System.out.println("Nev: " + nev + ", Ar: " + ar);
                }
            }

            
            
            // 3. Kiiratom a harmadik ugyfel adatait
            
            System.out.println("\n3. A harmadik ugyfel adatai: ");
            NodeList ugyfelek = doc.getElementsByTagName("Ugyfel");
            
            for (int i = 0; i < ugyfelek.getLength(); i++) {
            	
                Node node = ugyfelek.item(i);
                
                if (node.getNodeType() == Node.ELEMENT_NODE) {
                	
                    Element harmadikUgyfel = (Element) node;
                    
                    if (harmadikUgyfel.getElementsByTagName("nev").item(0).getTextContent().equals("Kato Andras")) {
                    	
                        System.out.println("Nev: " + harmadikUgyfel.getElementsByTagName("nev").item(0).getTextContent());
                        System.out.println("Szuletesi ev: " + harmadikUgyfel.getElementsByTagName("szul_ev").item(0).getTextContent());
                        System.out.println("Eletkor: " + harmadikUgyfel.getElementsByTagName("eletkor").item(0).getTextContent());
                        Element lakcim = (Element) harmadikUgyfel.getElementsByTagName("lakcim").item(0);
                        System.out.println("Lakcime: " +	lakcim.getElementsByTagName("irsz").item(0).getTextContent() + ", " +
						                                	lakcim.getElementsByTagName("kozseg").item(0).getTextContent() + ", " +
						                                	lakcim.getElementsByTagName("kozterulet").item(0).getTextContent() + " " +
						                                	lakcim.getElementsByTagName("hazszam").item(0).getTextContent());
						                                
                        NodeList aktivSzolgaltatasok = harmadikUgyfel.getElementsByTagName("aktivSzolgaltatas");
                        System.out.println("Aktiv szolgaltatasok: ");
                        
                        for (int j = 0; j < aktivSzolgaltatasok.getLength(); j++) {
                        	
                            System.out.println(" - " + aktivSzolgaltatasok.item(j).getTextContent());
                        }
                    }
                }
            }
            
            

            // 4. Oszetett lekerdezes: mentorok es eszkozgyartok nevei
            
            System.out.println("\n4. Mentorok es eszkozgyartok nevei:");
            NodeList mentorok = doc.getElementsByTagName("Mentor");
            NodeList eszkozgyartok = doc.getElementsByTagName("Eszkozgyarto");     
            
            for (int i = 0; i < Math.max(mentorok.getLength(), eszkozgyartok.getLength()); i++) {
            	
                String mentorNev = i < mentorok.getLength() ?  ((Element) mentorok.item(i)).getElementsByTagName("nev").item(0).getTextContent() : "-";
                String gyartoNev = i < eszkozgyartok.getLength() ? ((Element) eszkozgyartok.item(i)).getElementsByTagName("nev").item(0).getTextContent() : "-";
                System.out.println("Mentor: " + mentorNev + ", Eszkozgyarto: " + gyartoNev);
            }

        } 
        catch (Exception e) {
        	
            e.printStackTrace();
        }
    }
}
