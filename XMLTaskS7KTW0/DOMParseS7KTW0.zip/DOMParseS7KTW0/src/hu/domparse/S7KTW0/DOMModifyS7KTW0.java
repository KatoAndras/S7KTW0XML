package hu.domparse.S7KTW0;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DOMModifyS7KTW0 {

    public static void main(String[] args) {
    	
        try {
        	
        	// XMLS7KTW0.xml betoltes
            File inputFile = new File("XMLS7KTW0.xml");
            
            // Letrehozom a dokumentum epitot es betoltom
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();

            
            
            // 1. Az elso es masodik dolgozo nevenek a csereje
            NodeList dolgozok = doc.getElementsByTagName("Dolgozo");
            Node elsoDolgozo = dolgozok.item(0);
            Node harmadikDolgozo = dolgozok.item(2);

            if (elsoDolgozo.getNodeType() == Node.ELEMENT_NODE && harmadikDolgozo.getNodeType() == Node.ELEMENT_NODE) {
            	
                Element elsoDolgozoD1 = (Element) elsoDolgozo;
                Element harmadikDolgozoD3 = (Element) harmadikDolgozo;

                String elsoNev = elsoDolgozoD1.getElementsByTagName("nev").item(0).getTextContent();
                String harmadikNev = harmadikDolgozoD3.getElementsByTagName("nev").item(0).getTextContent();

                elsoDolgozoD1.getElementsByTagName("nev").item(0).setTextContent(harmadikNev);
                harmadikDolgozoD3.getElementsByTagName("nev").item(0).setTextContent(elsoNev);
            }

            
            
            // 2. Az elso szolglattas nevenek az atirasa
            NodeList szolgaltatasok = doc.getElementsByTagName("Szolgaltatas");
            Node elsoSzolgaltatas = szolgaltatasok.item(0);

            if (elsoSzolgaltatas.getNodeType() == Node.ELEMENT_NODE) {
            	
                Element elsoSzolgaltatasSZ1 = (Element) elsoSzolgaltatas;
                elsoSzolgaltatasSZ1.getElementsByTagName("nev").item(0).setTextContent("DSL");
            }

            
            
            // 3. Az elso ugyfel adatainak a torlese
            NodeList ugyfelek = doc.getElementsByTagName("Ugyfel");
            Node elsoUgyfel = ugyfelek.item(0);
            elsoUgyfel.getParentNode().removeChild(elsoUgyfel);

            
            
            // 4. Ugyintezesi idotartam szamok moge szoveg kiirasa (perc)
            NodeList ugyintezesek = doc.getElementsByTagName("Ugyintezes");
            for (int i = 0; i < ugyintezesek.getLength(); i++) {
            	
                Node ugyintezes = ugyintezesek.item(i);
                
                if (ugyintezes.getNodeType() == Node.ELEMENT_NODE) {
                	
                    Element ugyintezesPerc = (Element) ugyintezes;
                    String idotartam = ugyintezesPerc.getElementsByTagName("idotartam").item(0).getTextContent();
                    ugyintezesPerc.getElementsByTagName("idotartam").item(0).setTextContent(idotartam + " perc");
                }
            }

            // Mentes es konzolra iras
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            DOMSource source = new DOMSource(doc);

            StreamResult consoleResult = new StreamResult(System.out);
            transformer.transform(source, consoleResult);

        } 
        catch (Exception e) {
        	
            e.printStackTrace();
        }
    }
}
