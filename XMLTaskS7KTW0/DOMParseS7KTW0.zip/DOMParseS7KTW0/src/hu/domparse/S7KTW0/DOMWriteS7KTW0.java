package hu.domparse.S7KTW0;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class DOMWriteS7KTW0 {

    public static void main(String[] args) throws ParserConfigurationException, TransformerException {
    	
    	// Letrehozom a dokumentum epitot
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc = builder.newDocument();

        // Letrehozom a gyokerelemet
        Element root = doc.createElementNS("DOMS7KTW0", "TelekomCeg");
        doc.appendChild(root);

        // Hozzaadom az egyedeket
        root.appendChild(createDolgozok(doc));
        root.appendChild(createSzolgaltatasok(doc));
        root.appendChild(createUgyfelek(doc));
        root.appendChild(createMentorok(doc));
        root.appendChild(createEszkozgyartok(doc));
        root.appendChild(createUgyintezesek(doc));
        root.appendChild(createErtekesitesek(doc));

        // Ki kell a feladatnak megfeleloen irni XML fajlkent
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transf = transformerFactory.newTransformer();
        
        transf.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
        transf.setOutputProperty(OutputKeys.INDENT, "yes");

        DOMSource source = new DOMSource(doc);
        File myFile = new File("XMLS7KTW01.xml");

        StreamResult console = new StreamResult(System.out);
        StreamResult file = new StreamResult(myFile);

        //konzolra is es fajlba is
        transf.transform(source, console);
        transf.transform(source, file);
    }

    //Kiiratom a dolgozokat
    private static Node createDolgozok(Document doc) {
        Element dolgozok = doc.createElement("Dolgozok");

        dolgozok.appendChild(createDolgozo(doc, "D1", "Kerekes Andras", "1975", "D2D"));
        dolgozok.appendChild(createDolgozo(doc, "D2", "Juhász Ilona", "1985", "CC"));
        dolgozok.appendChild(createDolgozo(doc, "D3", "Habar Aladar", "2000", "Gyakornok"));
        return dolgozok;
    }
    private static Node createDolgozo(Document doc, String id, String nev, String szulEv, String beosztas) {
        Element dolgozo = doc.createElement("Dolgozo");
        dolgozo.setAttribute("dolg_id", id);

        dolgozo.appendChild(createElement(doc, "nev", nev));
        dolgozo.appendChild(createElement(doc, "szul_ev", szulEv));
        dolgozo.appendChild(createElement(doc, "beosztas", beosztas));
        return dolgozo;
    }

    
    // Kiiratom a szolgaltatasokat
    private static Node createSzolgaltatasok(Document doc) {
        Element szolgaltatasok = doc.createElement("Szolgaltatasok");

        szolgaltatasok.appendChild(createSzolgaltatas(doc, "SZ1", "D1", "Internet", "500", "optika"));
        szolgaltatasok.appendChild(createSzolgaltatas(doc, "SZ2", "D2", "TV", "1500", "koax"));
        szolgaltatasok.appendChild(createSzolgaltatas(doc, "SZ3", "D3", "Telefon", "300", "rez"));
        szolgaltatasok.appendChild(createSzolgaltatas(doc, "SZ4", "D2", "Mobil", "5000", "radio"));
        return szolgaltatasok;
    }
    private static Node createSzolgaltatas(Document doc, String id, String d_sz, String nev, String ar, String technologia) {
        Element szolgaltatas = doc.createElement("Szolgaltatas");
        szolgaltatas.setAttribute("szolg_id", id);
        szolgaltatas.setAttribute("d_sz", d_sz);

        szolgaltatas.appendChild(createElement(doc, "nev", nev));
        szolgaltatas.appendChild(createElement(doc, "ar", ar));
        szolgaltatas.appendChild(createElement(doc, "technologia", technologia));
        return szolgaltatas;
    }

    
    // Kiiratom az ugyfeleket
    private static Node createUgyfelek(Document doc) {
        Element ugyfelek = doc.createElement("Ugyfelek");

        ugyfelek.appendChild(createUgyfel(doc, "U1", "D1", "Kovacs Albert", "1990", "34", "3500", "Miskolc", "Hejo utca", "10", new String[]{"TV", "Internet"}));
        ugyfelek.appendChild(createUgyfel(doc, "U2", "D2", "Nemeth Lili", "1970", "54", "1200", "Budapest", "Rokon utca", "8", new String[]{"Telefon", "Mobil"}));
        ugyfelek.appendChild(createUgyfel(doc, "U3", "D3", "Kato Andras", "2000", "24", "3530", "Miskolc", "Sarolta utca", "8", new String[]{"Internet", "TV", "Telefon", "Mobil"}));
        return ugyfelek;
    }
    private static Node createUgyfel(Document doc, String id, String d_u, String nev, String szulEv, String eletkor,
                                     String irsz, String kozseg, String kozterulet, String hazszam, String[] aktivSzolgaltatasok) {
        Element ugyfel = doc.createElement("Ugyfel");
        ugyfel.setAttribute("ugyfel_id", id);
        ugyfel.setAttribute("d_u", d_u);

        ugyfel.appendChild(createElement(doc, "nev", nev));
        ugyfel.appendChild(createElement(doc, "szul_ev", szulEv));
        ugyfel.appendChild(createElement(doc, "eletkor", eletkor));

        Element lakcim = doc.createElement("lakcim");
        lakcim.appendChild(createElement(doc, "irsz", irsz));
        lakcim.appendChild(createElement(doc, "kozseg", kozseg));
        lakcim.appendChild(createElement(doc, "kozterulet", kozterulet));
        lakcim.appendChild(createElement(doc, "hazszam", hazszam));
        ugyfel.appendChild(lakcim);

        Element aktivSzolg = doc.createElement("aktivSzolgaltatasok");
        for (String szolg : aktivSzolgaltatasok) {
            aktivSzolg.appendChild(createElement(doc, "aktivSzolgaltatas", szolg));
        }
        ugyfel.appendChild(aktivSzolg);
        return ugyfel;
    }

    
    // Kiiratom a mentorokat
    private static Node createMentorok(Document doc) {
        Element mentorok = doc.createElement("Mentorok");

        mentorok.appendChild(createMentor(doc, "M1", "Hajdu Csilla", "06704682578", "5"));
        mentorok.appendChild(createMentor(doc, "M2", "Klinga Ferenc", "06304781236", "8"));
        mentorok.appendChild(createMentor(doc, "M3", "Kecskes Milan", "06704286996", "2"));
        return mentorok;
    }
    private static Node createMentor(Document doc, String id, String nev, String telefonszam, String ledolgozottEvek) {
        Element mentor = doc.createElement("Mentor");
        mentor.setAttribute("mentor_id", id);

        mentor.appendChild(createElement(doc, "nev", nev));
        mentor.appendChild(createElement(doc, "telefonszam", telefonszam));
        mentor.appendChild(createElement(doc, "ledolgozottEvek", ledolgozottEvek));
        return mentor;
    }

    
    // Kiiratom az eszkozgyartokat
    private static Node createEszkozgyartok(Document doc) {
        Element eszkozgyartok = doc.createElement("Eszkozgyartok");

        eszkozgyartok.appendChild(createEszkozgyarto(doc, "ESZ1", "Bajor Tech.", "1990", "12000"));
        eszkozgyartok.appendChild(createEszkozgyarto(doc, "ESZ2", "FinnTech", "2010", "150000"));
        eszkozgyartok.appendChild(createEszkozgyarto(doc, "ESZ3", "Clippy Technologies", "1950", "5000000"));
        return eszkozgyartok;
    }
    private static Node createEszkozgyarto(Document doc, String id, String nev, String alapitasEve, String bevetel) {
        Element eszkozgyarto = doc.createElement("Eszkozgyarto");
        eszkozgyarto.setAttribute("gyarto_id", id);

        eszkozgyarto.appendChild(createElement(doc, "nev", nev));
        eszkozgyarto.appendChild(createElement(doc, "alapitasEve", alapitasEve));
        eszkozgyarto.appendChild(createElement(doc, "bevetel", bevetel));
        return eszkozgyarto;
    }

    
    // Kiiratom az ugyintezeseket
    private static Node createUgyintezesek(Document doc) {
        Element ugyintezesek = doc.createElement("Ugyintezesek");

        ugyintezesek.appendChild(createUgyintezes(doc, "UGY1", "csomagvaltas", "12"));
        ugyintezesek.appendChild(createUgyintezes(doc, "UGY2", "szerzodesKerdes", "5"));
        ugyintezesek.appendChild(createUgyintezes(doc, "UGY3", "lemondas", "30"));
        return ugyintezesek;
    }
    private static Node createUgyintezes(Document doc, String id, String tipus, String idotartam) {
        Element ugyintezes = doc.createElement("Ugyintezes");
        ugyintezes.setAttribute("ugyintezes_id", id);

        ugyintezes.appendChild(createElement(doc, "tipus", tipus));
        ugyintezes.appendChild(createElement(doc, "idotartam", idotartam));
        return ugyintezes;
    }

    
    // Kiiratom az ertekesiteseket
    private static Node createErtekesitesek(Document doc) {
        Element ertekesitesek = doc.createElement("Ertekesitesek");

        ertekesitesek.appendChild(createErtekesites(doc, "ER1", "TV", "2024-12-07"));
        ertekesitesek.appendChild(createErtekesites(doc, "ER2", "Mobil", "2024-12-04"));
        ertekesitesek.appendChild(createErtekesites(doc, "ER3", "Internet", "2024-12-05"));
        return ertekesitesek;
    }
    private static Node createErtekesites(Document doc, String id, String megrendeles, String idopont) {
        Element ertekesites = doc.createElement("Ertekesites");
        ertekesites.setAttribute("ertekesites_id", id);

        ertekesites.appendChild(createElement(doc, "megrendeles", megrendeles));
        ertekesites.appendChild(createElement(doc, "idopont", idopont));
        return ertekesites;
    }

    //letrehozzuk az XML-t es visszaadjuk returnel
    private static Node createElement(Document doc, String name, String value) {
        Element node = doc.createElement(name);
        node.appendChild(doc.createTextNode(value));
        return node;
    }
}
