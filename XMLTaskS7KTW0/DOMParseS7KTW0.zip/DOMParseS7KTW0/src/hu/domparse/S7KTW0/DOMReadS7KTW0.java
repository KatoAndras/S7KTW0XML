package hu.domparse.S7KTW0;

import java.io.File;
import java.io.IOException;
import java.io.FileWriter;
import java.io.BufferedWriter;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;
import org.xml.sax.SAXException;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

public class DOMReadS7KTW0 {

    public static void main(String argv[]) throws SAXException, IOException, ParserConfigurationException {
    	
        // XMLS7KTW0.xml betoltes
        File xmlFile = new File("XMLS7KTW0.xml");

        // Letrehozom a dokumentum epitot es betoltom
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = factory.newDocumentBuilder();

        Document doc = dBuilder.parse(xmlFile);
        doc.getDocumentElement().normalize();

        // Ki kellesz irni fajlba, igy megadom mi legyen a neve a kiirt fajlnak
        BufferedWriter writer = new BufferedWriter(new FileWriter("DOMReadS7KTW0out.txt"));

        // Kiirom a gyoker elemet (TelekomCeg)
        String rootElement = doc.getDocumentElement().getNodeName();
        String output = "Gyoker elem: " + rootElement;
        
        System.out.println(output);
        writer.write(output);
        writer.newLine();

        // Kiiratom a dolgozokat
        NodeList dolgozokList = doc.getElementsByTagName("Dolgozo");
        for (int i = 0; i < dolgozokList.getLength(); i++) {
        	
            Node dolgozoNode = dolgozokList.item(i);
            
            if (dolgozoNode.getNodeType() == Node.ELEMENT_NODE) {
            	
                Element dolgozoElem = (Element) dolgozoNode;

                String dolg_id = dolgozoElem.getAttribute("dolg_id");
                String nev = dolgozoElem.getElementsByTagName("nev").item(0).getTextContent();
                String szul_ev = dolgozoElem.getElementsByTagName("szul_ev").item(0).getTextContent();
                String beosztas = dolgozoElem.getElementsByTagName("beosztas").item(0).getTextContent();

                output = "\nDolgozo ID: " + dolg_id + "\nNev: " + nev + "\nSzul_ev: " + szul_ev + "\nBeosztas: " + beosztas;
                
                System.out.println(output);
                writer.write(output);
                writer.newLine();
          }
        }

        // Kiiratom a szolgaltatasokat
        NodeList szolgaltatasokList = doc.getElementsByTagName("Szolgaltatas");
        for (int i = 0; i < szolgaltatasokList.getLength(); i++) {
        	
            Node szolgaltatasNode = szolgaltatasokList.item(i);
            
            if (szolgaltatasNode.getNodeType() == Node.ELEMENT_NODE) {
            	
                Element szolgaltatasElem = (Element) szolgaltatasNode;

                String szolg_id = szolgaltatasElem.getAttribute("szolg_id");
                String d_sz = szolgaltatasElem.getAttribute("d_sz");
                String nev = szolgaltatasElem.getElementsByTagName("nev").item(0).getTextContent();
                String ar = szolgaltatasElem.getElementsByTagName("ar").item(0).getTextContent();
                String technologia = szolgaltatasElem.getElementsByTagName("technologia").item(0).getTextContent();

                output = "\nSzolgaltatas ID: " + szolg_id + "\nDolgozo ID: " + d_sz + "\nNev: " + nev + "\nAr: " + ar + "\nTechnologia: " + technologia;
                
                System.out.println(output);
                writer.write(output);
                writer.newLine();
             }
        }

        // Kiiratom az ugyfeleket
        NodeList ugyfelekList = doc.getElementsByTagName("Ugyfel");
        for (int i = 0; i < ugyfelekList.getLength(); i++) {
        	
            Node ugyfelNode = ugyfelekList.item(i);
            
            if (ugyfelNode.getNodeType() == Node.ELEMENT_NODE) {
            	
                Element ugyfelElem = (Element) ugyfelNode;

                String ugyfel_id = ugyfelElem.getAttribute("ugyfel_id");
                String d_u = ugyfelElem.getAttribute("d_u");
                String nev = ugyfelElem.getElementsByTagName("nev").item(0).getTextContent();
                String szul_ev = ugyfelElem.getElementsByTagName("szul_ev").item(0).getTextContent();
                String eletkor = ugyfelElem.getElementsByTagName("eletkor").item(0).getTextContent();

                output = "\nUgyfel ID: " + ugyfel_id + "\nDolgozo ID: " + d_u + "\nNev: " + nev + "\nSzul_ev: " + szul_ev + "\nEletkor: " + eletkor;
                
                System.out.println(output);
                writer.write(output);
                writer.newLine();

                // Lakcimek, mivel osszetettek meg kell adni, vagy nem fog megjelenni egyaltalan
                Node lakcimNode = (Node) ugyfelElem.getElementsByTagName("lakcim").item(0);
                
                String irsz = ((Element) lakcimNode).getElementsByTagName("irsz").item(0).getTextContent();
                String kozseg = ((Element) lakcimNode).getElementsByTagName("kozseg").item(0).getTextContent();
                String kozterulet = ((Element) lakcimNode).getElementsByTagName("kozterulet").item(0).getTextContent();
                String hazszam = ((Element) lakcimNode).getElementsByTagName("hazszam").item(0).getTextContent();

                output = "Lakcim: " + irsz + " " + kozseg + " " + kozterulet + " " + hazszam;
                
                System.out.println(output);
                writer.write(output);
                writer.newLine();

                // Mint a lakcimek, az aktiv szolgaltatasokat is kulon ki kell irni
                NodeList aktivSzolgaltatasokList = ugyfelElem.getElementsByTagName("aktivSzolgaltatasok");
                for (int j = 0; j < aktivSzolgaltatasokList.getLength(); j++) {
                	
                    Node aktivSzolgaltatasokNode = aktivSzolgaltatasokList.item(j);
                    
                    if (aktivSzolgaltatasokNode.getNodeType() == Node.ELEMENT_NODE) {
                        Element aktivSzolgaltatas = (Element) aktivSzolgaltatasokNode;

                        // Barmilyen variacio lehet, for-al megvizsgalom, es kiiratom az osszes aktiv szolgaltatast
                        NodeList szolgaltatasok = aktivSzolgaltatas.getElementsByTagName("aktivSzolgaltatas");
                        for (int k = 0; k < szolgaltatasok.getLength(); k++) {
                        	
                            Node szolgaltatasNode = szolgaltatasok.item(k);
                            
                            if (szolgaltatasNode.getNodeType() == Node.ELEMENT_NODE) {
                                String szolgaltatasNev = szolgaltatasNode.getTextContent();
                                
                                output = "Aktiv Szolgaltatas: " + szolgaltatasNev;
                                
                                System.out.println(output);
                                writer.write(output);
                                writer.newLine();
                            }
                        }
                      }
                }
         }
        }

        // Kiiratom a mentorokat
        NodeList mentorokList = doc.getElementsByTagName("Mentor");
        
        for (int i = 0; i < mentorokList.getLength(); i++) {
        	
            Node mentorNode = mentorokList.item(i);
            
            if (mentorNode.getNodeType() == Node.ELEMENT_NODE) {
            	
                Element mentorElem = (Element) mentorNode;

                String mentor_id = mentorElem.getAttribute("mentor_id");
                String nev = mentorElem.getElementsByTagName("nev").item(0).getTextContent();
                String telefonszam = mentorElem.getElementsByTagName("telefonszam").item(0).getTextContent();
                String ledolgozottEvek = mentorElem.getElementsByTagName("ledolgozottEvek").item(0).getTextContent();

                output = "\nMentor ID: " + mentor_id + "\nNev: " + nev + "\nTelefonszam: " + telefonszam + "\nLedolgozott Evek: " + ledolgozottEvek;
                
                System.out.println(output);
                writer.write(output);
                writer.newLine();
           }
        }

        // Kiiratom az eszkozgyartokat
        NodeList eszkozgyartokList = doc.getElementsByTagName("Eszkozgyarto");
        for (int i = 0; i < eszkozgyartokList.getLength(); i++) {
        	
            Node eszkozgyartoNode = eszkozgyartokList.item(i);
            
            if (eszkozgyartoNode.getNodeType() == Node.ELEMENT_NODE) {
            	
                Element eszkozgyartoElem = (Element) eszkozgyartoNode;

                String gyarto_id = eszkozgyartoElem.getAttribute("gyarto_id");
                String nev = eszkozgyartoElem.getElementsByTagName("nev").item(0).getTextContent();
                String alapitasEve = eszkozgyartoElem.getElementsByTagName("alapitasEve").item(0).getTextContent();
                String bevetel = eszkozgyartoElem.getElementsByTagName("bevetel").item(0).getTextContent();

                output = "\nEszkozgyarto ID: " + gyarto_id + "\nNev: " + nev + "\nAlapitas eve: " + alapitasEve + "\nBevetel: " + bevetel;
                
                System.out.println(output);
                writer.write(output);
                writer.newLine();
            }
        }
        
     // Kiiratom az ugyintezeseket
        NodeList ugyintezesekList = doc.getElementsByTagName("Ugyintezes");
        for (int i = 0; i < ugyintezesekList.getLength(); i++) {
        	
            Node ugyintezesNode = ugyintezesekList.item(i);
            
            if (ugyintezesNode.getNodeType() == Node.ELEMENT_NODE) {
            	
                Element ugyintezesElem = (Element) ugyintezesNode;

                String ugyintezes_id = ugyintezesElem.getAttribute("ugyintezes_id");
                String tipus = ugyintezesElem.getElementsByTagName("tipus").item(0).getTextContent();
                String idotartam = ugyintezesElem.getElementsByTagName("idotartam").item(0).getTextContent();

                output = "\nUgyintezes ID: " + ugyintezes_id + "\nTipus: " + tipus + "\nIdotartam: " + idotartam;
                
                System.out.println(output);
                writer.write(output);
                writer.newLine();
            }
        }

        // Kiiratom az ertekesiteseket
        NodeList ertekesitesekList = doc.getElementsByTagName("Ertekesites");
        for (int i = 0; i < ertekesitesekList.getLength(); i++) {
        	
            Node ertekesitesNode = ertekesitesekList.item(i);
            
            if (ertekesitesNode.getNodeType() == Node.ELEMENT_NODE) {
            	
                Element ertekesitesElem = (Element) ertekesitesekList.item(i);

                String ertekesites_id = ertekesitesElem.getAttribute("ertekesites_id");
                String megrendeles = ertekesitesElem.getElementsByTagName("megrendeles").item(0).getTextContent();
                String idopont = ertekesitesElem.getElementsByTagName("idopont").item(0).getTextContent();

                output = "\nErtekesites ID: " + ertekesites_id + "\nMegrendeles: " + megrendeles + "\nIdopont: " + idopont;
                
                System.out.println(output);
                writer.write(output);
                writer.newLine();
            }
        }

        // fajliras vege
        writer.close();
    }
}
