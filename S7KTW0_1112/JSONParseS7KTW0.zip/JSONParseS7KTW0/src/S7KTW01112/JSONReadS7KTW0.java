package S7KTW01112;

import java.io.FileReader;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class JSONReadS7KTW0 {

	public static void main(String[] args) {
		
		try(FileReader reader = new FileReader("orarendS7KTW0.json")){
			
			//parse
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObject = (JSONObject)jsonParser.parse(reader);
			
			//Root, majd �ralista lek�r�s
			JSONObject root = (JSONObject) jsonObject.get("KA_orarend");
			JSONArray KA = (JSONArray) root.get("ora");
			
			//�ra adatok ki�r�sa
			System.out.println("�rarend: Programtervez� 2024\n");
			
			for(int i=0; i<KA.size(); i++){
				
				JSONObject lesson = (JSONObject) KA.get(i);
				JSONObject time = (JSONObject) lesson.get("idopont");
				System.out.println("T�rgy: " + lesson.get("targy"));
				System.out.println("Id�pont: " + time.get("nap") + " " + time.get("tol") + "-" + time.get("ig") + "-ig");
				System.out.println("Helysz�n: " + lesson.get("helyszin"));
				System.out.println("Oktat�: " + lesson.get("oktato"));
				System.out.println("Szak: " + lesson.get("szak") +"\n");
			}
			
		}catch(Exception e){
			System.out.println("Hiba l�pett fel!");
		}
		
	}

}
