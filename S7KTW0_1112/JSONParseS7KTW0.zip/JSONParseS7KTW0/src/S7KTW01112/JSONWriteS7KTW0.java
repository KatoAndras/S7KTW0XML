package S7KTW01112;

import java.io.FileReader;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


public class JSONWriteS7KTW0 {

	public static void main(String[] args) {
		
		JSONArray KA = new JSONArray();
		KA.add(createLesson("Adatkezel�s XML-ben", "kedd", "10", "12", "Inf/103", "Dr. Bednarik L�szl�", "Programtervez� Informatikus"));
		KA.add(createLesson("Adatkezel�s XML-ben", "kedd", "12", "14", "Inf/103", "Dr. Bednarik L�szl�", "Programtervez� Informatikus"));
		KA.add(createLesson("Szoftvertechnol�gia", "szerda", "08", "10", "III. El�ad�", "Dr. Mileff P�ter", "Programtervez� Informatikus"));
		KA.add(createLesson("Szoftvertechnol�gia", "szerda", "10", "12", "III. El�ad�", "Dr. Mileff P�ter", "Programtervez� Informatikus"));
		
		JSONObject root = new JSONObject();
		root.put("ora", KA);
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("KA_orarend", root);
		
		fileWrite(jsonObject, "orarendKA.json");
		consoleWrite(jsonObject);
	}
	
	//Jav�t�s!!!!
	private static void fileWrite(JSONObject jsonObject, String fileName){
		
		try(FileWriter weiter = new FileWriter){
			writer.write()
		}
		
	}
	//Jav�t�s!!!!
	
	private static void consoleWrite(JSONObject jsonObject){
		
		System.out.println("JSON dokumentum tartalma:\n");
		
		JSONObject root = (JSONObject) jsonObject.get("KA_orarend");
		JSONArray KA = (JSONArray) root.get("ora");
		
		for(int i=0; i<KA.size(); i++){
			JSONObject lesson = (JSONObject) KA.get(i);
			JSONObject time = (JSONObject) lesson.get("idopont");
			System.out.println("T�rgy: " + lesson.get("targy"));
			System.out.println("Id�pont: " + time.get("nap") + " " + time.get("tol") + "-" + time.get("ig") + "-ig");
			System.out.println("Helysz�n: " + lesson.get("helyszin"));
			System.out.println("Oktat�: " + lesson.get("oktato"));
			System.out.println("Szak: " + lesson.get("szak") +"\n");
		}	
	}
	
	//Indent�l�s f�jlba �r�shoz
	private static String indentJson(String json){
		String out = "";
		int indent = 0;
		for(int i =0; i<json.length()-1; i++){
			out += json.charAt(i);
			if(json.charAt(i) == ','){
				out +=  "\n" + " ".repeat(indent>0 ? indent : 0);
			}else if (json.charAt(i) == '{' | json.charAt(i) == '['){
				indent++;
				out += "\n" + " ".repeat(indent>0 ?indent:0);
			}else if((json.charAt(i+1) == '}' || json.charAt(i+1) == ']')){
				indent--;
				out += "\n" + " ".repeat(indent>0 ? indent : 0);
			}
		}
		out+=json.charAt(json.length()-1);
		return out;
	}
	
	//�ra objektum k�sz�t�se
	private static JSONObject createLesson(String subject, String day, String from, String to, String place, String teacher, String major){
		JSONObject lesson = new JSONObject();
		JSONObject time = new JSONObject();
		time.put("nap", day);
		time.put("tol", from);
		time.put("ig", to);
		lesson.put("targy", subject);
		lesson.put("idopont", time);
		lesson.put("helyszin", place);
		lesson.put("oktato", teacher);
		lesson.put("szak", major);
		return lesson;
	}

}
