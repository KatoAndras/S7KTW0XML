package xpathS7KTW01119;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;

import org.xml.sax.SAXException;

public class xPathS7KTW0 {

	public static void main(String[] args) {
		try{
			
			//File xmlFile = new File("hallgatoS7KTW0.xml");
			
			//DocumentBuilder l�trehoz�sa
			
			DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
			
			DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
			
			Document document = documentBuilder.parse("hallgatoS7KTW0.xml");
			
			// Az XML dokumentum normaliz�l�sa, vagyis elt�vol�tjuk a felesleges whitespace karaktereket,
			// �s egy�b normaliz�l�si l�p�seket hajtunk v�gre, hogy egys�ges legyen a dokumentum szerkezete.
			document.getDocumentElement().normalize();
			
			//az XPath k�sz�t�se
			XPath xPath = XPathFactory.newInstance().newXPath();
			
			//Meg kell adni az el�r�si �t kifejez�st �s a csom�pont list�t:
			
			String KA = "class";
			//String KA = "/class/hallgato";
			//String KA = "/class/hallgato[2]";
			
			
			//K�sz�tsen egy list�t, majd xPath kifejez�st le kell ford�tani �s ki kell �rt�kelni
			NodeList neptunKod = (NodeList) xPath.compile(KA).evaluate(document, XPathConstants.NODESET);
			System.out.println("Test");

			//A for  ciklus seg�ts�g�vel a NodeList csom�pontjain v�gig kell iter�lni
			for(int i = 0; i < neptunKod.getLength(); i++){
				
				//Kivessz�k a NodeList-b�l az akru�lis Node elemet.
				Node node = neptunKod.item(i);
				
				System.out.println("\nAktu�lis elem: " + node.getNodeName());
				
				//Meg kell vizsg�lni a csom�pontot, tesztelni kell a subelemet.
				if(node.getNodeType() == Node.ELEMENT_NODE && node.getNodeName().equals("hallgato")){
					
					//A Node elemet Element-t� konvert�ljuk, hogy hozz�f�rhess�nk az elem specifikus met�dusaihoz
					Element element = (Element) node;
					
					//az id attributomot ad vissza
					System.out.println("Hallgat� ID: " + element.getAttribute("id"));
					
					//keresztnevet ad vissza
					System.out.println("Keresztn�v: " + element.getElementsByTagName("keresztnev").item(0).getTextContent());
					
					//vezet�knevet ad vissza
					System.out.println("Vezet�kn�v: " + element.getElementsByTagName("vezeteknev").item(0).getTextContent());
					
					//kort ad vissza
					System.out.println("Kor: " + element.getElementsByTagName("kor").item(0).getTextContent());
				}
			}
		}catch (ParserConfigurationException e){
			e.printStackTrace();
		}catch (SAXException e){
			e.printStackTrace();
		}catch (IOException e){
			e.printStackTrace();
		}catch (XPathExpressionException e){
			e.printStackTrace();
		}		

	}

}
